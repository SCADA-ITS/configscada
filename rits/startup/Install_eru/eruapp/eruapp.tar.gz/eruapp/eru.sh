#!/bin/bash
cd /home/eru/arbitrer
./arbitrer.sh &
sleep 120
cd /home/eru/eruapp
_now=$(date +"%d_%m_%Y_%H_%M_%S")
_file1="/home/eru/eruapp/salida_$_now.out"
_file2="/home/eru/eruapp/error_$_now.out"
_file3="/home/eru/eruapp/logs/telventTELVENT1_$_now.txt"
_file4="/home/eru/eruapp/logs/telventTELVENT2_$_now.txt"
cp salida.out "$_file1"
cp error.out "$_file2"
cp /home/eru/eruapp/logs/telventTELVENT1.txt "$_file3"
cp /home/eru/eruapp/logs/telventTELVENT2.txt "$_file4"

java -cp .:./lib/antlr-2.7.6rc1.jar:./lib/cglib-2.1.3.jar:./lib/commons-collections.jar:./lib/dom4j-1.6.jar:./lib/commons-logging-1.0.4.jar:./lib/hibernate3.jar:./lib/hivemind-1.1.1.jar:./lib/hivemind-lib-1.1.1.jar:./lib/hivemind-jmx-1.1.1.jar:./lib/cintra-base-conf.jar:./lib/ERUCoreProject-0.0.1.jar -Dnet.wimpi.modbus.debug=false -Dcom.sun.management.jmxremote.port=1199 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false com.cintra.eru.core.App






