> /home/eru/eruapp/logs/inserts.log.5000
> /home/eru/eruapp/logs/inserts.log.5001
> /home/eru/eruapp/logs/inserts.log.5002
> /home/eru/eruapp/logs/inserts.log.5003
> /home/eru/eruapp/logs/queries_length.log.5000
> /home/eru/eruapp/logs/queries_length.log.5001
> /home/eru/eruapp/logs/queries_length.log.5002
> /home/eru/eruapp/logs/queries_length.log.5003
> /home/eru/eruapp/logs/queries_speed.log.5000
> /home/eru/eruapp/logs/queries_speed.log.5001
> /home/eru/eruapp/logs/queries_speed.log.5002
> /home/eru/eruapp/logs/queries_speed.log.5003

