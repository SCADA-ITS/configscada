#!/bin/sh
cd /home/eru/eruconnector
java -cp ./:./ERUMangoConnectorProject-1.0.0.jar -Djava.util.logging.config.file=/home/eru/eruconnector/logging.properties com.cintra.eru.SimpleBridgeApp /home/eru/eruconnector/connectors.json 

