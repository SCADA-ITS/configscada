#!/bin/bash
cd /home/eru/arbitrer
java -cp .:./lib/ERUUtilProject-1.0.0.jar com.cintra.eru.util.SimpleBusArbitrer 28999


